# 1-stud building: HISTORY (one user's sessions)

Log of how the rules came about. Not rules. Optional when sharing the style files: it records this user's taste and decisions so others don't mix them up with their own.

## Session 1: forest + props
- The v2 sky-island lobby was disliked as "simulator slop"; moved to a frontier forest camp in 1-stud style.
- Voxel-built props (clutter-set.js) rejected → the two-layer idea (grid structure + classic props).
- The user's own barrel (box + Weld bands) set the prop language; crates took many rounds (crossing slabs, rim bands, thin seams all rejected).
- The 2-part mushroom was praised: constraints as a tool.

## Session 2: exacts, checks, campfire, tent, wagon
- Guide gaps found: no structure colours, no scale anchor, no built-structure recipe, grid checked by eye, mesh sizes guessed.
- gridCheck written; it immediately caught the forest corner's 1×2 bricks half a stud off grid.
- Answers: meshes measured (sizes.rbxmx, newmeshes.rbxmx), standard 5-stud R6 player as scale, 0.5 ground steps, 1-stud cubes, colours found as we go, no texture caps, messiness 6/10 heavy, true-scale props.
- Trees must have Weld splotches. Wood always carries Weld.
- Campfire v1 too cramped ("feet on fire") → spacing rule. Cylinders on the centrepiece disliked → rotated blocks tried → ropes and sticks fought the style → rotated builds scrapped for now (only whole props rotate).
- A TikTok reference campfire: chunky, the fire is the feature, little gradienting. Insight: Inlet lets surfaces carry texture without tone-mixing; gradienting is fine on nature but not spammed on set pieces → one-tone set pieces.
- Campfire v2 approved (stone ring outside, logs inside; had it backwards once). The user added a clean Studs finish to the dirt in Roblox.
- Wagon: stepped wheels proposed and rejected as voxel ("silhouette over all") → round things stay round; ask "should this be round?". The barrel is a box, not a cylinder. No textures on cylinders (warp). Tongue too thin → every part 1-stud style. Half studs allowed. Tyres removed: singular vs multi detail.
- Scale drift admitted; player stand-in, Eye view and scaleCheck added. scaleCheck flagged the sack (too tall), the small wagon barrel and the tent door (2 × 4).
- Campfire + tent + wagon stitched in Roblox looked like a showcase, not a lobby → large-sets.md and staged building.
- Guide split into style / references / tools / large-sets / history.

## Session 4: sandy plateau (first finished big set)
- After the coast failure the user asked for a stepping stone: one landmark, a 100×100 plot, rules from the coast lessons. Built in approved stages: blockout → temple → dressing → props → polish.
- Feedback that shaped it: the temple must dominate the whole cliff side ("giant ruined temple, not a display"); columns as cylinders (rounded things read as pixel art when blocky), clustered shafts with a better base and top; statue head as the Head mesh then the user's tiki head; palms must not be clones (generator with Weld, Studs, wedges, balls); two palms on the second level; vines instead of brown roots; use kit meshes for props, with preview stand-ins; Bowl mesh is upside-down on import; pebbles flush on the stud grid; Bush and Sprout only.
- Props brief from the user: a desert civilization left in a hurry, sea and jungle taking it back; mood quiet, sun-bleached, a little sad; pots, broken stone, offerings, traces of people, plants taking over; cream/sand palette plus one terracotta.
